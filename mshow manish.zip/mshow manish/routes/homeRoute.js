var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/Mshow');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to DB-homeroute");
});

var bookingSchema = mongoose.Schema({
    Title : String,
    City : String,
    Theatre : String,
    Date : String,
    ShowTiming : String,
    Seats : Array,
    bookedseats : Array
});



var userbooking = mongoose.model('userbooking',bookingSchema, 'userbooking');

 
router.route('/userbooking').get(function(req, res) {
  userbooking.find({}, function (err, docs) {
  res.json(docs);
  });
});


router.post('/newbooking', function (req, res) {
  var booking = new userbooking({
    Title: req.body.Title,
    City: req.body.City,
  Theatre: req.body.Theatre,
    Date: req.body.Date,
    ShowTiming: req.body.ShowTiming,
      Seats : req.body.Seats,
      bookedseats :req.body.bookedseats
  });
  booking.save(function(err,docs){
    console.log('booking Saved Successfully'+docs);

  });
});

module.exports = router ;