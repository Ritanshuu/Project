module.exports = function($scope, $http,$rootScope,$location){
        
    //seat controller starts
    var settings = {
               rows: 5,
               cols: 15,
               rowCssPrefix: 'row-',
               colCssPrefix: 'col-',
               seatWidth: 35,
               seatHeight: 35,
               seatCss: 'seat',
               selectedSeatCss: 'selectedSeat',
               selectingSeatCss: 'selectingSeat'
           };

var init = function (reservedSeat) {
                var str = [], seatNo, className;
                for (i = 0; i < settings.rows; i++) {
                    for (j = 0; j < settings.cols; j++) {
                        seatNo = (i + j * settings.rows + 1);
                        className = settings.seatCss + ' ' + settings.rowCssPrefix + i.toString() + ' ' + settings.colCssPrefix + j.toString();
                        if ($.isArray(reservedSeat) && $.inArray(seatNo, reservedSeat) != -1) {
                            className += ' ' + settings.selectedSeatCss;
                        }
                        str.push('<li class="' + className + '"' +
                                  'style="top:' + (i * settings.seatHeight).toString() + 'px;left:' + (j * settings.seatWidth).toString() + 'px">' +
                                  '<a title="' + seatNo + '">' + seatNo + '</a>' +
                                  '</li>');
                    }
                }
                $('#place').html(str.join(''));
            };
            //case I: Show from starting
            //init();
 
            //Case II: If already booked
            var bookedSeats = [];
            
     // var allbook = bookedSeats.concat(str);
   //         init(allbook);
    
            init(bookedSeats);
    
    
$('.' + settings.seatCss).click(function () {
if ($(this).hasClass(settings.selectedSeatCss)){
    alert('This seat is already reserved');
}
else{
    $(this).toggleClass(settings.selectingSeatCss);
    }
});
 
//$('#btnShow').click(function () {
//    var str = [];
//    $.each($('#place li.' + settings.selectedSeatCss + ' a, #place li.'+ settings.selectingSeatCss + ' a'), function (index, value) {
//        str.push($(this).attr('title'));
//    });
//    alert(str.join(','));
//})
    
       
$('#btnShowNew').click(function () {
    var str = [], item;
    $.each($('#place li.' + settings.selectingSeatCss + ' a'), function (index, value) {
        item = $(this).attr('title');                   
        str.push(item);                   
    });
$rootScope.showseats =str.join(',');
   $rootScope.seats = str;
    
});
    
    
//seat controller end //////////////////////////////
// mapping controller ////////////////////////////// 
    
    var init = function(){

      $http.get('/mapapi/moviemapping').success(function (response) {
        $scope.mappingData=response;
      });
        
        $http.get('/bookapi/userbooking').success(function (response) {
        $scope.bookingData=response;
      });
        
       $http.get('/bookapi/userseat').success(function (response) {
       $rootScope.bookedseats=response;
      });
        
    };
    init();
        
    $scope.book = function(){
        $scope.booking.Seats=$rootScope.seats;          
        $rootScope.bookedtitle = $scope.booking.Title;
        $rootScope.bookedtheatre = $scope.booking.Theatre;
      //  $scope.booking.bookedseats = $scope.booking.bookedseats.concat(seats);
            $.merge(bookedtheatre,seats);
     $http.post('/bookapi/newbooking', $scope.booking).success(function (response) {
    });
        
    };
    
     $scope.delete = function(map){
    var x=confirm("Are you sure you want to delete ?");
    if(x){
      $http.delete('/bookapi/deletebooking/'+map._id).success(function (response) {
    });
  }
    window.location.reload();
  };
        
};