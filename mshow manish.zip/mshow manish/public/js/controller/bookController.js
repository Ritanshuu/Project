module.exports = function($scope, $http,$rootScope,$location){
    
    
 var init = function(){
     
     $http.get('/bookapi/userbooking').success(function (response) {
        $scope.bookingData=response;
      });
     
 };
    init();
    
};