var express = require('express');
var theatreroute = require('./route/TheatreRoute');
var movieroute = require('./route/MovieRoute');
var mappingroute = require('./route/MappingRoute');
var timingroute = require('./route/TimingRoute');
var app = express();
var bodyParser = require('body-parser');

app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());

app.use('/demo', theatreroute);
app.use('/mvr', movieroute);
app.use('/tmr', timingroute);
app.use('/map', mappingroute);

if (app.get('env') === 'development') {
 var webpackMiddleware = require("webpack-dev-middleware");
 var webpack = require('webpack');

 var config = require('./webpack.config');

 app.use(webpackMiddleware(webpack(config), {
   publicPath: "/build",

   headers: { "X-Custom-Webpack-Header": "yes" },

   stats: {
     colors: true
   }
 }));

}



var server = app.listen(7700, function () {
 console.log('listening on port 7700');
});
