module.exports = function($scope, $http,$rootScope,$location){
 $scope.movieData="hello";
 $rootScope.data="";

$scope.searchMovie = function(){
$http.get('http://www.omdbapi.com/?t='+$scope.name+'&y='+$scope.year+'&plot=short&r=json').then(successCallback, errorCallback);

function successCallback(response)
{
   $scope.movieData=response;
   $rootScope.data=response;
   console.log(response);
   if($scope.movieData.length==0)
   {
   alert('ERROR : No movie found .');
   console.log('ERROR : No movie found .');
   }
}
function errorCallback(error){
   console.log(error);
}
};



$scope.add = function(ob){
 $http.post('/data/newmovie/'+ob.title+"/"+ob.actor+"/"+ob.year+"/"+ob.runtime+"/"+ob.director+"/"+ob.language).then(successCallback, errorCallback);
 function successCallback(response)
 {
 init();
 $scope.ob.title='';
 $scope.ob.actor='';
     $scope.ob.year='';
     $scope.ob.runtime='';
     $scope.ob.director='';
     $scope.ob.language='';
 window.location.reload();
 init();
   alert('saved');
}
function errorCallback(error)
{
   console.log(error);
}
};

$scope.delete = function(Movie){
 var x=confirm("Are you sure you want to delete ?");
 if(x){
   $http.delete('/data/deletemovie/'+Movie._id).success(function (response) {
 });
}
window.location.reload();

 alert('delete');
};


};
