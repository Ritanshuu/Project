var app = require('angular').module('bsmdemo');
app.controller('MovieController', require('./movieController'));
app.controller('TheatreController', require('./theatreController'));
app.controller('MappingController', require('./mappingController'));
app.controller('TimingController', require('./timingcontroller'));
app.controller('SeatController', require('./seatController'));

