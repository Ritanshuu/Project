module.exports = function($scope, $http,$rootScope,$location)
{
  $rootScope.data="";

  $scope.demo="Hello";
      var init = function()
      {
          $http.get('/demo/mapping').then(successCallback, errorCallback);
          function successCallback(response)
              {
                $scope.demo=response.data;
                console.log(response.data);
              }
          function errorCallback(error)
              {
                  console.log(error);
              }
      };
init();

$scope.insert = function(ob)
    {
      $http.post('/demo/newmapping/'+ob.mc+"/"+ob.mn+"/"+ob.cc+"/"+ob.sr+"/"+ob.nos+"/"+ob.md).then(successCallback, errorCallback);
    
        function successCallback(response)
          {
              init();
                  $scope.ob.mc='';
                  $scope.ob.mn='';
                  $scope.ob.cc='';
                  $scope.ob.sr='';
                  $scope.ob.nos='';
                  $scope.ob.md='';
              window.location.reload();
              init();
                alert('saved');
          }
    
        function errorCallback(error)
            {
                console.log(error);
            }
    };
};
