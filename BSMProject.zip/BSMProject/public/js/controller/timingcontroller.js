module.exports = function($scope, $http,$rootScope,$location){
    
    $rootScope.data="";
    
    var init = function(){
  $http.get('/mvr/movie').then(successCallback, errorCallback);
  function successCallback(response)
  {
    $scope.data=response.data;
    console.log(response.data);
  }
  function errorCallback(error)
  {
      console.log(error);
  }
};
    
    $rootScope.data="";
    
    var init = function(){
  $http.get('/demo/theatres').then(successCallback, errorCallback);
  function successCallback(response)
  {
    $scope.data=response.data;
    console.log(response.data);
  }
  function errorCallback(error)
  {
      console.log(error);
  }
};
init();
    
      $scope.insert = function (add) {
		 
		 var dt = $('#date').val();
		 
         ft=moment(ft).format('L');		
		 
		 $scope.add.fromdate=ft;
	
		 
		         $http.post('/adate/addtiming', asnmovies).success(function (response) {
                                
                                console.log(response);
                                console.log("CREATE IS SUCCESSFUL");
                                refresh();
                            });
       
    };


};