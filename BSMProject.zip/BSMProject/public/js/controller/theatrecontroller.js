module.exports = function($scope, $http,$rootScope,$location){
  $rootScope.data="";

  var init = function(){
  $http.get('/demo/theatres').then(successCallback, errorCallback);
  function successCallback(response)
  {
    $scope.data=response.data;
    console.log(response.data);
  }
  function errorCallback(error)
  {
      console.log(error);
  }
};
init();

$scope.insert = function(ob){
  $http.post('/demo/newTheatre/'+ob.theatre+"/"+ob.city).then(successCallback, errorCallback);
  function successCallback(response)
  {
  init();
  $scope.ob.theatre='';
  $scope.ob.city='';
  init();
    alert('saved');

}
function errorCallback(error)
{
    console.log(error);
}
    window.location.reload();
};

$scope.delete = function(theatre){
  var x=confirm("Are you sure you want to delete ?");
  if(x){
    $http.delete('/demo/deleteTheatre/'+theatre._id).then(successCallback, errorCallback);
  function successCallback(response){

  }
      function errorCallback(error)
{
    console.log(error);
}
      alert('removed');
    window.location.reload();
}
  init();
};
};
