'use strict'

var angular = require('angular');
    require('angular-route');

var app= angular.module('bsmdemo',['ngRoute']);
    require('./controller');

app.config(function($routeProvider)
{
            $routeProvider.when('/',{
            templateUrl: 'view/home.html'
    }).when('/movie',{
            templateUrl: 'view/movie.html',
            controller: 'MovieController'
    }).when('/theatre',{
            templateUrl: 'view/theatre.html',
            controller: 'TheatreController'
    }).when('/mapping',{
            templateUrl: 'view/mapping.html',
            controller: 'MappingController'
    }).when('/timing',{
            templateUrl: 'view/timing.html',
            controller: 'TimingController'
    }).when('/seatbook',{
            templateUrl: 'view/seatbooking.html',
            controller: 'SeatController'
    }).when('/login',{
            templateUrl: 'view/login.html',
            /*controller: ''*/
    }).when('/signup',{
            templateUrl: 'view/new_account.html',
           /* controller: ''*/
    }).when('/book',{
            templateUrl: 'view/bookmovie.html',
           /* controller: ''*/
            })
});
