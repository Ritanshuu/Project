var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/ManishShow');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to DB theatre route");
});


router.get('/theatres', function (req, res) {
    Theatre.find({}, function (err, docs) {
    res.json(docs);
    });
});

module.exports = router;