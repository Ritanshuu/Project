var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MEAN_Ritanshu');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to DB");
});

var movieSchema = mongoose.Schema({
  title: String,
  actor: String,
  year: String,
  runtime: String,
  director: String,
  language: String    
});

var movie = mongoose.model('movie',movieSchema, 'movie');

router.post('/newmovie/:t/:a/:y/:r/:d/:l', function (req, res) {
  var movie = new movie({
    title: req.params.t,
    actor: req.params.a,
    year: req.params.y,
    runtime: req.params.r,
    director: req.params.d,
    language: req.params.l
  });
  movie.save(function(err,docs){
    console.log('movie Saved Successfully');
  });
});

router.delete('/deletemovie/:id',function(req, res){
  movie.remove({_id:req.params.id},function(err, docs){
    console.log('movie Removed Successfully');
  });
});

router.get('/movie', function (req, res) {
    movie.find({}, function (err, docs) {
    res.json(docs);
    });
});


module.exports = router;
