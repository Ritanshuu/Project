var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser');
var router = express.Router();

router.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/MEAN_Ritanshu');
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function(){
  console.log("Connected to DB");
});

var MappingSchema = mongoose.Schema({
    mc: String,
    mn: String,
    cc: String,
    sr: String,
    nos: String,
    md: String    
});

var Mapping = mongoose.model('Mapping',MappingSchema, 'Mapping');
//  Mapping.save(function(err,docs){
//      console.log('mapping Saved Successfully');
//    });


router.get('/mapping', function (req, res){
        Mapping.find({}, function (err, docs){
            res.json(docs);
        });
    });

module.exports = router;
