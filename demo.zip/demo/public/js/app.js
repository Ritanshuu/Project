'use strict'

var angular = require('angular');
require('angular-route');

var app= angular.module('myproject',['ngRoute']);
require('./Controller');

app.config(function($routeProvider)
{
  $routeProvider.when('/',{
        templateUrl: 'views/home.html',
      //  controller: 'HomeController',
  }).when('/search',{
    templateUrl: 'views/movie.html',
   controller: 'SelectController'
 }).when('/theatre',{
   templateUrl: 'views/theatre.html',
  controller: 'TheatreController'
})
});
