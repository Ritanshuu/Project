'use strict'

var angular = require('angular');
require('angular-route');

var app= angular.module('bsmdemo',['ngRoute']);
require('./controller');

app.config(function($routeProvider)
{
  $routeProvider.when('/',{
        templateUrl: 'view/movie.html',
      //  controller: 'HomeController',
  }).when('/movie',{
    templateUrl: 'view/movie.html',
   controller: 'SelectController'
 }).when('/theatre',{
   templateUrl: 'view/theatre.html',
  controller: 'TheatreController'
})
});
