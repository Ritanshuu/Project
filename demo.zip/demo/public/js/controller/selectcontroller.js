module.exports = function($scope, $http,$rootScope,$location){
  $scope.movieData="hello";
  $rootScope.data="";

$scope.searchMovie = function(){
$http.get('http://www.omdbapi.com/?t='+$scope.name+'&y='+$scope.year+'&plot=short&r=json').then(successCallback, errorCallback);

function successCallback(response)
{
    $scope.movieData=response;
    $rootScope.data=response;
    console.log(response);
    if($scope.movieData.length==0)
    {
    alert('ERROR : No movie found .');
    console.log('ERROR : No movie found .');
    }
}
function errorCallback(error){
    console.log(error);
}
};

};
