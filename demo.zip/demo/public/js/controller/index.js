var app = require('angular').module('myproject');
app.controller('SelectController', require('./SelectController'));
app.controller('TheatreController', require('./TheatreController'));
