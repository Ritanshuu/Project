var app = require('angular').module('bsmdemo');
app.controller('SelectController', require('./selectController'));
app.controller('TheatreController', require('./theatreController'));
