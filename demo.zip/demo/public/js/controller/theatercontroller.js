module.exports = function($scope, $http,$rootScope,$location){
  $rootScope.data="";

  $scope.demo="Hello";
  var init = function(){
  $http.get('/demo/theatres').then(successCallback, errorCallback);
  function successCallback(response)
  {
    $scope.demo=response.data;
    console.log(response.data);
  }
  function errorCallback(error)
  {
      console.log(error);
  }
};
init();

$scope.insert = function(ob){
  $http.post('/demo/newTheatre/'+ob.theatre+"/"+ob.city).then(successCallback, errorCallback);
  function successCallback(response)
  {
  init();
  $scope.ob.theatre='';
  $scope.ob.city='';
  window.location.reload();
  init();
    alert('saved');
}
function errorCallback(error)
{
    console.log(error);
}
};

$scope.delete = function(theatre){
  var x=confirm("Are you sure you want to delete ?");
  if(x){
    $http.delete('/demo/deleteTheatre/'+theatre._id).success(function (response) {
  });
}
window.location.reload();
  init();
  alert('removed');
};

};
