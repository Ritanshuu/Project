var express = require('express');
var mongoose = require('mongoose');
var router = express.Router();
var bodyParser = require('body-parser');
router.use(bodyParser.urlencoded({ extended: true }));


var BookingSchema = mongoose.Schema({
    Title : String,
    City : String,
    Date: String,
    Time:String,
    Theatre : String,
    Show : String,
    SeatNo : [],
    Quantity : String,
    Amount : String
});

var Booking = mongoose.model('Booking',BookingSchema, 'Booking');

router.post('/booking', function (req, res) {
  var mapping = new Booking({
    Title: req.params.Title,
    City: req.params.City,
    Date: req.params.Date,
    Time: req.params.Time,
    Theatre: req.params.Theatre,
    Show: req.params.Show,
    SeatNo: JSON.parse(req.params.SeatNo),
    Quantity: req.params.Quantity,
    Amount: req.params.Amount,
  });
  booking.save(function(err,docs){
    console.log('Booking Saved Successfully'+docs);
  });
});

router.get('/bookedseats/:Title/:Theatre/:Show', function (req, res) {
  Booking.find({Title:req.params.Title,Theatre:req.params.Theatre,Show:req.params.Show}, function (err, docs) {
    res.json(docs);
    });
});

module.exports = router;
