'use strict';
var app = require('angular').module('theatreApp');
app.service('AuthService',  require('./auth-service'));
