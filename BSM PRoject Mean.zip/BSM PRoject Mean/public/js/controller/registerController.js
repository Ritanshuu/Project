'use strict';

module.exports = function ($scope, $q, $location, AuthService) {

    $scope.register = function () {


      $scope.error = false;
      $scope.disabled = true;

      
      AuthService.register($scope.registerForm.username, $scope.registerForm.password, $q)
        
        .then(function () {
          $location.path('/login');
          $scope.disabled = false;
          $scope.registerForm = {};
        })
        
        .catch(function () {
          $scope.error = true;
          $scope.errorMessage = "Something went wrong!";
          $scope.disabled = false;
          $scope.registerForm = {};
        });

    };

}