module.exports = function($scope, $http, $rootScope,$location){
var s_seat=0,no_of_seat,no;
var countdiv=[];
  var seatOnload = function(){
  $(document).ready(function(){
    $('#Seatclass').change(function(){
      var sel=$('#Seatclass').find(":selected").text();
      if(sel=="classic")
      {

      $('#genral tr>td>div').addClass('grey');
      $('#classic tr>td>div').removeClass('grey');
      }

      if(sel=="genral")
      {
        $('#classic tr>td>div').addClass('grey');
        $('#genral tr>td>div').removeClass('grey');
      }

    $('#noofseats').change(function(){
       no = $('#noofseats').find(":selected").text();
      no_of_seat=document.getElementById("totalst").innerHTML= no;




    $('.floating-box').click(function(){

    if(!$(this).hasClass('grey')||$(this).hasClass('red'))
    {
  
      if(countdiv.length < no)
      {

        $(this).toggleClass("d1");
        var id=$(this).attr('id');
        var cn=$(this).hasClass('d1');

        if(cn)
            {

                countdiv.push(id);
                  $rootScope.TotalSeat=JSON.stringify(countdiv);
              s_seat= document.getElementById("st").innerHTML=countdiv;
              // count++;
              }

        else{
              var ind=countdiv.indexOf(id);
              countdiv.splice(ind,1);
              $rootScope.TotalSeat=JSON.stringify(countdiv);
            }
  if(sel== "genral")
  {
    document.getElementById("amt").innerHTML=countdiv.length*150;
  }
  else
  {
    document.getElementById("amt").innerHTML=countdiv.length*250;
  }

  }
  else {
    
          alert("Request you to  book only " + no +" seats");
    }
  }
  });


  });
  });

  });
};
seatOnload();

      var init = function(){
      $http.get('/mapapi/moviemapping').success(function (response) {
        $scope.mappingData=response;
      });
    };
    init();

$scope.nextPage =function(){
$rootScope.Amount=document.getElementById("amt").innerHTML;
$rootScope.TotalSeat1= s_seat;
$rootScope.coutSeat=no_of_seat;
     $http.post('/pay/booking', $scope.booking).success(function (response) {
    });   

if(countdiv.length==no_of_seat)
{

$location.path('/payment');
}
else {
  alert('Please Reselect No. of Seats');
}

};



var init=function()
{
  var Title=$rootScope.Title;
  var Theatre=$rootScope.Theatre;
  var Time=$rootScope.Time;
  var Date=$rootScope.Date;

  $http.get('/pay/bookedseats/'+m+'/'+t+'/'+s).success(function (response) {
    for(i=0;i<response.length;i++)
    {
      for(j=0;j<response[i].SeatNo.length;j++)
      {
          $('#'+response[i].SeatNo[j]).addClass('red');
      }
    }
  });
};
 
    /*$scope.confirmPage =function(){

  Title=$rootScope.Title,
  City=$rootScope.City,
  Theatre=$rootScope.Theatre,
  Time=$rootScope.Time,
  TotalSeat=$rootScope.TotalSeat,
  coutSeat=$rootScope.coutSeat,
  amt=$rootScope.Amount,
  Date=$rootScope.Date,
  $http.post('/pay/booking/'+Title+'/'+City+'/'+Theatre+'/'+Time'/'+TotalSeat+'/'+coutSeat+'/'+amt+'/'+Date).success(function (response){});
$location.path('/confirmationPage');

};
*/


}
