  'use strict';

module.exports = function ($scope, $q, $location, AuthService) {

    $scope.login = function () {

      
      $scope.error = false;
      $scope.disabled = true;


      AuthService.login($scope.loginForm.username, $scope.loginForm.password, $q)

        .then(function () {
          $location.path('/');
          $scope.disabled = false;
          $scope.loginForm = {};
        })
       
          .catch(function () {
          $scope.error = true;
          $scope.errorMessage = "Invalid username and/or password";
          $scope.disabled = false;
          $scope.loginForm = {};
        });

    };

}
