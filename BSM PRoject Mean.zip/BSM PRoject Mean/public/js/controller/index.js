var app = require('angular').module('theatreApp');
app.controller('TheatreController', require('./theatreController'));
app.controller('MovieController', require('./movieController'));
app.controller('MappingController', require('./mappingController'));
app.controller('SeatController', require('./seatcontroller'));
app.controller('RegisterController', require('./registerController'));
app.controller('LoginController', require('./loginController'));
app.controller('LogoutController', require('./logoutController'));